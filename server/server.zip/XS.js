const mongoose = require('mongoose');

// MongoDB connection URI without specifying the database name
const dbURI = 'mongodb+srv://adnaan:adnaan420@cms-cluster0.stv241q.mongodb.net/?retryWrites=true&w=majority&appName=CMS-Cluster0/CMS';

// Define the name of the desired database
const dbName = 'NEWNEW';

// Define a schema for your data
const dataSchema = new mongoose.Schema({
  // Define your schema fields here
  name: String,
  age: Number,
  email: String,
  file:Buffer,
  // Add more fields as needed
});

// Define a model based on the schema
const Data = mongoose.model('Data', dataSchema);

// Connect to MongoDB database
mongoose.connect(dbURI, { useNewUrlParser: true, useUnifiedTopology: true, dbName });

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));

// When the connection is open, perform database operation
db.once('open', async () => {
  console.log('Connected to MongoDB');

  try {
    // Create a new document
    const newData = new Data({
      name: 'John Doe',
      age: 30,
      email: 'john.doe@example.com'
      // Add more data fields as needed
    });

    // Save the document to the database
    await newData.save();
    console.log('Data saved successfully');

    // Close the database connection
    mongoose.connection.close();
  } catch (error) {
    console.error('Error saving data:', error);
    // Close the database connection in case of error
    mongoose.connection.close();
  }
});
