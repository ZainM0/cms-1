const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const complaintSchema = new Schema({
  crimeTitle: String,
  crimeDescription: String,
  dateTime: Date,
  policeStation: String
});

const Complaint = mongoose.model('Complaint', complaintSchema);

module.exports = Complaint;
