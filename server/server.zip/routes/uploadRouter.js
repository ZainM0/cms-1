const express = require('express');
const router = express.Router();
const uploadController = require('../controllers/uploadController');
const upload = require('../middleware/upload');

router.post('/', upload.array('mediaFiles'), uploadController.uploadFile);

module.exports = router;
