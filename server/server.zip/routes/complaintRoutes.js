const express = require('express');
const router = express.Router();
const complainController = require('../controller/complainController');
router.post('/', complainController.createComplaint);

const { updateComplaint } = require('../controller/complainController'); // Import the controller function if you have one

// Route to handle admin updates for complaints
router.post('/complaints/:id/update', updateComplaint);

module.exports = router;