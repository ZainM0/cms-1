const Complaint = require('../models/complainModel');

// Function to handle admin updates for complaints
exports.updateComplaint = async (req, res) => {
    try {
        const id = req.params.id;
        const { updateText } = req.body;

        // Find the complaint by ID and update its updates array
        const updatedComplaint = await Complaint.findByIdAndUpdate(id, {
            $push: { updates: updateText }
        }, { new: true });

        res.status(200).json(updatedComplaint);
    } catch (error) {
        console.error('Error updating complaint:', error);
        res.status(500).json({ message: 'Failed to update complaint. Please try again later.' });
    }
};

exports.createComplaint = async (req, res) => {
    try {
        console.log(req.body);
        const { crimeTitle, crimeDescription, dateTime, mediaFiles, policeStation } = req.body;
        const complaint = await Complaint.create({ crimeTitle, crimeDescription, dateTime, mediaFiles, policeStation });
        
        const newComplaint = new Complaint(req.body);
        const savedComplaint = await newComplaint.save();
        console.log('Saved complaint:', savedComplaint); // Log the saved complaint
        res.status(201).json(savedComplaint);


    } catch (error) {
        console.error('Error creating complaint:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
