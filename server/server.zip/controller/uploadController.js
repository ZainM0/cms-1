const mongoose = require('mongoose');
const Grid = require('gridfs-stream');
const Media = require('../models/mediaModel');
const Complaint = require('../models/complaintModel');

const conn = mongoose.connection;
let gfs;

conn.once('open', () => {
  gfs = Grid(conn.db, mongoose.mongo);
  gfs.collection('uploads');
});

const uploadFile = async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ message: 'No files were uploaded.' });
    }

    const complaint = new Complaint({
      crimeTitle: req.body.crimeTitle,
      crimeDescription: req.body.crimeDescription,
      dateTime: req.body.dateTime,
      policeStation: req.body.policeStation
    });

    // Save complaint to get its ID
    await complaint.save();

    // Upload each file to GridFS
    for (const file of req.files) {
      const writeStream = gfs.createWriteStream({
        filename: file.originalname,
        metadata: { complaintId: complaint._id }
      });
      writeStream.write(file.buffer);
      writeStream.end();
    }

    return res.status(200).json({ message: 'Files uploaded successfully.' });
  } catch (error) {
    console.error('Error uploading files:', error);
    return res.status(500).json({ message: 'Internal server error.' });
  }
};

module.exports = {
  uploadFile
};
